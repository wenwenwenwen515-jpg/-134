package com.idormy.sms.forwarder.model.vo;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.BatteryManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import com.idormy.sms.forwarder.MyApplication;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.idormy.sms.forwarder.utils.SettingUtil;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.Data;

@Data
public class SmsVo implements Serializable {
    String mobile;
    String content;
    Date date;
    String simInfo;

    public SmsVo() {
    }

    public SmsVo(String mobile, String content, Date date, String simInfo) {
        this.mobile = mobile;
        this.content = content;
        this.date = date;
        this.simInfo = simInfo;
    }

    @SuppressLint("SimpleDateFormat")
    public String getSmsVoForSend(String ruleSmsTemplate) {
        String deviceMark = getDeviceDisplay();
        String customSmsTemplate = "{{短信内容}}\n\n{{卡槽信息}}\n{{设备名称}}\n{{安卓系统}}\n{{系统版本}}\n手机电量：{{手机电量}}\n短信接收时间：{{接收时间}}";

        //优先取转发规则的自定义模板，留空则取全局设置
        if (!ruleSmsTemplate.isEmpty()) {
            customSmsTemplate = ruleSmsTemplate;
        } else {
            boolean switchSmsTemplate = SettingUtil.getSwitchSmsTemplate();
            String smsTemplate = SettingUtil.getSmsTemplate().trim();
            if (switchSmsTemplate && !smsTemplate.isEmpty()) {
                customSmsTemplate = smsTemplate;
            }
        }

        return customSmsTemplate.replace("{{来源号码}}", mobile).replace("{{APP包名}}", mobile)
                .replace("{{短信内容}}", content).replace("{{通知内容}}", content)
                .replace("{{卡槽信息}}", TextUtils.isEmpty(simInfo) ? "卡1：未读取" : maskSimInfo(simInfo))
                .replace("{{接收时间}}", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date))
                .replace("{{推送时间}}", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()))
                .replace("{{手机电量}}", getBatteryLevel() < 0 ? "未读取" : getBatteryLevel() + "%")
                .replace("{{设备名称}}", deviceMark)
                .replace("{{安卓系统}}", getAndroidVersion())
                .replace("{{系统版本}}", getSystemVersion())
                .trim();
    }

    // 仅对推送显示的 SIM 号码做脱敏，不修改内部 SIM 信息或号码匹配逻辑。
    // 例：卡1：17815161718 -> 卡1：1781***718（显示前4位和后3位，中间隐藏）
    private String maskSimInfo(String value) {
        if (TextUtils.isEmpty(value)) return value;
        int colon = value.indexOf('：');
        if (colon < 0) colon = value.indexOf(':');
        if (colon < 0 || colon + 1 >= value.length()) return value;
        String label = value.substring(0, colon + 1);
        String number = value.substring(colon + 1).trim();
        StringBuilder digits = new StringBuilder();
        for (int i = 0; i < number.length(); i++) {
            char c = number.charAt(i);
            if (Character.isDigit(c)) digits.append(c);
        }
        if (digits.length() < 8) return label + number;
        return label + digits.substring(0, 4) + "***" + digits.substring(digits.length() - 3);
    }

    private String getDeviceDisplay() {
        String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.trim();
        String brand = Build.BRAND == null ? "" : Build.BRAND.trim();
        String model = Build.MODEL == null ? "" : Build.MODEL.trim();
        model = getSalesModel(model);
        String lower = (manufacturer + " " + brand).toLowerCase();
        String name;
        if (lower.contains("huawei")) name = "华为";
        else if (lower.contains("honor")) name = "荣耀";
        else if (lower.contains("xiaomi") || lower.contains("redmi") || lower.contains("poco")) name = "小米";
        else if (lower.contains("oppo") || lower.contains("oplus")) name = "OPPO";
        else if (lower.contains("oneplus")) name = "一加";
        else if (lower.contains("realme")) name = "realme";
        else if (lower.contains("vivo") || lower.contains("iqoo")) name = "vivo";
        else if (lower.contains("samsung")) name = "三星";
        else if (lower.contains("motorola") || lower.contains("moto")) name = "摩托罗拉";
        else name = !TextUtils.isEmpty(manufacturer) ? manufacturer : brand;
        return "设备：" + name + (TextUtils.isEmpty(model) ? "" : " " + model);
    }

    private String getAndroidVersion() {
        String release = Build.VERSION.RELEASE == null ? "未知" : Build.VERSION.RELEASE;
        return "Android " + release + "（API " + Build.VERSION.SDK_INT + "）";
    }

    // 将常见内部型号映射为用户更熟悉的销售名称；未知型号保留系统返回值。
    private String getSalesModel(String model) {
        if (TextUtils.isEmpty(model)) return model;
        String normalized = model.trim().toUpperCase(java.util.Locale.ROOT);
        if ("ANG-AN00".equals(normalized)) return "nova 10";
        if ("NCO-AL00".equals(normalized)) return "nova 10 Pro";
        return model;
    }

    private int getBatteryLevel() {
        try {
            Context context = MyApplication.getInstance();
            if (context == null) return -1;
            Intent battery = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (battery != null) {
                int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                if (level >= 0 && scale > 0) return Math.round(level * 100f / scale);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                BatteryManager manager = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
                if (manager != null) {
                    int level = manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                    if (level >= 0 && level <= 100) return level;
                }
            }
        } catch (Throwable ignored) { }
        return -1;
    }

    private String getSystemVersion() {
        String maker = ((Build.MANUFACTURER == null ? "" : Build.MANUFACTURER) + " " +
                (Build.BRAND == null ? "" : Build.BRAND)).toLowerCase(java.util.Locale.ROOT);

        // 先按设备厂商判断，避免把其他品牌的 ro.build.display.id 误认成 Flyme。
        if (maker.contains("huawei") || maker.contains("华为")) {
            String value = firstProperty("ro.build.version.harmony", "ro.huawei.build.version", "ro.build.version.emui");
            if (!TextUtils.isEmpty(value)) return "系统版本：" + (value.toLowerCase(java.util.Locale.ROOT).contains("harmony") ? "" : "HarmonyOS ") + value;
        }
        if (maker.contains("honor")) {
            String value = firstProperty("ro.build.version.magic", "ro.build.version.emui");
            if (!TextUtils.isEmpty(value)) return "系统版本：MagicOS " + value;
        }
        if (maker.contains("oppo") || maker.contains("oneplus") || maker.contains("realme") || maker.contains("oplus")) {
            String value = firstProperty("ro.build.version.opporom", "ro.oplus.version", "ro.build.version.coloros");
            if (!TextUtils.isEmpty(value)) return "系统版本：ColorOS " + value;
        }
        if (maker.contains("vivo") || maker.contains("iqoo")) {
            String value = firstProperty("ro.vivo.os.version", "ro.build.version.vivo");
            if (!TextUtils.isEmpty(value)) return "系统版本：OriginOS " + value;
        }
        if (maker.contains("xiaomi") || maker.contains("redmi") || maker.contains("poco")) {
            String value = firstProperty("ro.miui.ui.version.name", "ro.mi.os.version.name");
            if (!TextUtils.isEmpty(value)) return "系统版本：" + (value.startsWith("V") ? "HyperOS " : "MIUI ") + value;
        }
        if (maker.contains("samsung")) {
            String value = firstProperty("ro.build.version.oneui", " ro.build.version.release");
            if (!TextUtils.isEmpty(value)) return "系统版本：One UI " + value;
        }
        if (maker.contains("meizu") || maker.contains("魅族")) {
            String value = firstProperty("ro.build.display.id", "ro.flyme.version.name");
            if (!TextUtils.isEmpty(value)) return "系统版本：Flyme " + value;
        }
        // 其他厂商只使用明确的系统属性，不再把通用 display.id 当作 Flyme。
        String generic = firstProperty("ro.build.version.harmony", "ro.build.version.opporom", "ro.vivo.os.version", "ro.miui.ui.version.name");
        return TextUtils.isEmpty(generic) ? "系统版本：未读取" : "系统版本：" + generic;
    }

    private String firstProperty(String... keys) {
        for (String key : keys) {
            String value = readSystemProperty(key.trim());
            if (!TextUtils.isEmpty(value) && !"unknown".equalsIgnoreCase(value) && !"null".equalsIgnoreCase(value)) return value.trim();
        }
        return "";
    }

    private String readSystemProperty(String key) {
        try {
            Class<?> clazz = Class.forName("android.os.SystemProperties");
            java.lang.reflect.Method method = clazz.getMethod("get", String.class, String.class);
            return String.valueOf(method.invoke(null, key, ""));
        } catch (Throwable ignored) {
            return "";
        }
    }

    @NonNull
    @Override
    public String toString() {
        return "SmsVo{" +
                "mobile='" + mobile + '\'' +
                ", content='" + content + '\'' +
                ", date=" + date +
                ", simInfo=" + simInfo +
                '}';
    }
}
