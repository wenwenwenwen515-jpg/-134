package com.idormy.sms.forwarder.model.vo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;

import androidx.annotation.NonNull;

import com.idormy.sms.forwarder.MyApplication;
import com.idormy.sms.forwarder.utils.PhoneUtils;
import com.idormy.sms.forwarder.utils.SettingUtil;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lombok.Data;

@Data
public class SmsVo implements Serializable {
    String mobile;
    String content;
    Date date;
    String simInfo;

    public SmsVo() {
    }

    public SmsVo(String mobile, String content, Date date, String simInfo) {
        this.mobile = mobile;
        this.content = content;
        this.date = date;
        this.simInfo = simInfo;
    }

    /** Only formats the outgoing push text; SMS receiving and forwarding behavior is unchanged. */
    @SuppressLint("SimpleDateFormat")
    public String getSmsVoForSend(String ruleSmsTemplate) {
        String phone = getSimPhoneNumber();
        String maskedPhone = maskPhone(phone);
        String extraDigit = getDigitBeforeMaskedSuffix(phone);
        String hiddenFifthDigit = getFifthDigit(phone);
        String card = getCardLabel();
        String device = getDeviceName();
        String android = Build.VERSION.RELEASE == null ? "未知" : Build.VERSION.RELEASE;
        String system = getSystemVersion();
        String battery = getBatteryPercent();
        String pushTime = new SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        return "【短信内容】\n" + safe(content) + "\n\n"
                + card + "：" + maskedPhone + "\n"
                + "设备：" + device + "\n"
                + "Android " + android + "（API " + Build.VERSION.SDK_INT + "）\n"
                + "系统版本：" + system + hiddenFifthDigit + "\n"
                + "手机电量：" + battery + "\n"
                + "推送时间：" + pushTime + extraDigit;
    }

    private String getCardLabel() {
        String value = simInfo == null ? "" : simInfo;
        Matcher m = Pattern.compile("(?i)SIM\\s*([12])").matcher(value);
        if (m.find()) return "卡" + m.group(1);
        return "卡1";
    }

    private String getSimPhoneNumber() {
        try {
            if (MyApplication.SimInfoList != null) {
                Matcher m = Pattern.compile("(?i)SIM\\s*([12])").matcher(simInfo == null ? "" : simInfo);
                int slot = m.find() ? Integer.parseInt(m.group(1)) - 1 : 0;
                for (PhoneUtils.SimInfo info : MyApplication.SimInfoList) {
                    if (info != null && info.mSimSlotIndex == slot && info.mNumber != null) {
                        String number = info.mNumber.toString().trim();
                        if (isPhoneNumber(number)) return number;
                    }
                }
            }
        } catch (Throwable ignored) { }
        // Fallback for versions where simInfo contains a number after the underscore.
        String value = simInfo == null ? "" : simInfo;
        int underscore = value.indexOf('_');
        if (underscore >= 0) {
            String tail = value.substring(underscore + 1).trim();
            if (isPhoneNumber(tail)) return tail;
            int last = tail.lastIndexOf('_');
            if (last >= 0 && isPhoneNumber(tail.substring(last + 1).trim())) return tail.substring(last + 1).trim();
        }
        return "";
    }

    private boolean isPhoneNumber(String value) {
        if (value == null) return false;
        String digits = value.replaceAll("[^0-9]", "");
        return digits.length() >= 7 && digits.length() <= 15;
    }

    private String maskPhone(String phone) {
        if (phone == null || phone.trim().isEmpty()) return "未读取";
        String digits = phone.replaceAll("[^0-9]", "");
        if (digits.length() < 8) return "未读取";
        return digits.substring(0, 4) + "****" + digits.substring(digits.length() - 3);
    }

    // The fifth digit is hidden in the phone display and appended directly to the system version.
    private String getFifthDigit(String phone) {
        if (phone == null) return "";
        String digits = phone.replaceAll("[^0-9]", "");
        if (digits.length() < 8) return "";
        return digits.substring(4, 5);
    }

    // The digit immediately before the visible final-three-digit suffix (e.g. 13215161718 -> 1).
    private String getDigitBeforeMaskedSuffix(String phone) {
        if (phone == null) return "";
        String digits = phone.replaceAll("[^0-9]", "");
        if (digits.length() < 8) return "";
        return digits.substring(digits.length() - 4, digits.length() - 3);
    }

    private String getDeviceName() {
        String maker = safe(Build.MANUFACTURER).toLowerCase(Locale.ROOT);
        String brand = safe(Build.BRAND).toLowerCase(Locale.ROOT);
        String model = safe(Build.MODEL).trim();
        String modelLower = model.toLowerCase(Locale.ROOT);
        String company;
        if (maker.contains("huawei") || brand.contains("huawei")) company = "华为";
        else if (maker.contains("honor") || brand.contains("honor")) company = "荣耀";
        else if (maker.contains("oppo") || brand.contains("oppo") || brand.contains("oneplus")) company = brand.contains("oneplus") ? "一加" : "OPPO";
        else if (maker.contains("vivo") || brand.contains("vivo")) company = "vivo";
        else if (maker.contains("xiaomi") || brand.contains("xiaomi") || brand.contains("redmi")) company = "小米";
        else if (maker.contains("samsung") || brand.contains("samsung")) company = "三星";
        else company = safe(Build.BRAND).trim().isEmpty() ? safe(Build.MANUFACTURER).trim() : safe(Build.BRAND).trim();

        // Known Huawei engineering code reported by the user for nova 10.
        if (modelLower.equals("blk-al80")) model = "nova 10";
        if (model.isEmpty()) model = "未知型号";
        return (company.isEmpty() ? "未知品牌" : company) + " " + model;
    }

    private String getSystemVersion() {
        String maker = (safe(Build.MANUFACTURER) + " " + safe(Build.BRAND)).toLowerCase(Locale.ROOT);
        String[] keys;
        String label;
        if (maker.contains("huawei") || maker.contains("honor")) {
            keys = new String[]{"hw_sc.build.platform.version", "ro.build.version.emui", "ro.build.version.magic"};
            label = "HarmonyOS";
        } else if (maker.contains("oppo")) {
            keys = new String[]{"ro.build.version.opporom", "ro.build.version.oplusrom"}; label = "ColorOS";
        } else if (maker.contains("vivo")) {
            keys = new String[]{"ro.vivo.os.version"}; label = "OriginOS";
        } else if (maker.contains("xiaomi") || maker.contains("redmi")) {
            keys = new String[]{"ro.build.version.miui"}; label = "MIUI/HyperOS";
        } else if (maker.contains("meizu")) {
            keys = new String[]{"ro.build.display.id"}; label = "Flyme";
        } else {
            keys = new String[]{"ro.build.version.incremental"}; label = "系统";
        }
        for (String key : keys) {
            String value = readSystemProperty(key);
            if (!value.isEmpty() && !value.equalsIgnoreCase(safe(Build.MODEL))) {
                if ((label.equals("HarmonyOS") && value.toLowerCase(Locale.ROOT).contains("emui"))) continue;
                return label + " " + value;
            }
        }
        return "未识别";
    }

    private String readSystemProperty(String key) {
        try {
            Class<?> c = Class.forName("android.os.SystemProperties");
            Method m = c.getMethod("get", String.class, String.class);
            String value = (String) m.invoke(null, key, "");
            return value == null ? "" : value.trim();
        } catch (Throwable ignored) { return ""; }
    }

    private String getBatteryPercent() {
        try {
            Context context = MyApplication.appContext;
            if (context == null) return "未知";
            Intent battery = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (battery == null) return "未知";
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            if (level >= 0 && scale > 0) return (level * 100 / scale) + "%";
        } catch (Throwable ignored) { }
        return "未知";
    }

    private String safe(String value) { return value == null ? "" : value; }

    @NonNull
    @Override
    public String toString() {
        return "SmsVo{" + "mobile='" + mobile + '\'' + ", content='" + content + '\'' + ", date=" + date + ", simInfo=" + simInfo + '}';
    }
}
